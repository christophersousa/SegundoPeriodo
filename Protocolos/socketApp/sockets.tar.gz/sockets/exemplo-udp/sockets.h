#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>

#define SERVER_UDP_PORT 8000

#define MAX_MSG 255		/* Tamanho maximo das mensagens */

