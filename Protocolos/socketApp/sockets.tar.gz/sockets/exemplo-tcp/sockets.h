#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>

#define SERVER_TCP_PORT 8000

#define MAX_MSG 1024		/* Tamanho maximo das mensagens */

